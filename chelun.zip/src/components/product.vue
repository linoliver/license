<template>
  <div>
    chanpin
  </div>
</template>

<script>
export default {

}
</script>

<style lang='scss'>

</style>
