<template>
  <ul class="talk">
    <li>
      <dl>
        <dt>
          <img src="http://picture.eclicks.cn/g2/l/2018/12/29/8b64b3c45968151c_482_315.png" alt="">
        </dt>
        <dd>
          <h2>如何用数字化手段对汽车行业的销售运营进行改造和升级</h2>
          <div class="label"><span class="label1">原创</span><span class="label2">市场动态</span>
          <span class="fr">520</span></div>
          <p class="desc">多种数字化手段在汽车行业销售运营中的应用</p>
          <p class="author"><span></span><span>2018/10/19</span></p>	 
        </dd>                
      </dl>
        <dl>
        <dt>
          <img src="http://picture.eclicks.cn/g2/l/2018/12/29/8b64b3c45968151c_482_315.png" alt="">
        </dt>
        <dd>
          <h2>如何用数字化手段对汽车行业的销售运营进行改造和升级</h2>
          <div class="label"><span class="label1">原创</span><span class="label2">市场动态</span>
          <span class="fr">520</span></div>
          <p class="desc">多种数字化手段在汽车行业销售运营中的应用</p>
          <p class="author"><span></span><span>2018/10/19</span></p>	 
        </dd>                
      </dl>
        <dl>
        <dt>
          <img src="http://picture.eclicks.cn/g2/l/2018/12/29/8b64b3c45968151c_482_315.png" alt="">
        </dt>
        <dd>
          <h2>如何用数字化手段对汽车行业的销售运营进行改造和升级</h2>
          <div class="label"><span class="label1">原创</span><span class="label2">市场动态</span>
          <span class="fr">520</span></div>
          <p class="desc">多种数字化手段在汽车行业销售运营中的应用</p>
          <p class="author"><span></span><span>2018/10/19</span></p>	 
        </dd>                
      </dl>
        <dl>
        <dt>
          <img src="http://picture.eclicks.cn/g2/l/2018/12/29/8b64b3c45968151c_482_315.png" alt="">
        </dt>
        <dd>
          <h2>如何用数字化手段对汽车行业的销售运营进行改造和升级</h2>
          <div class="label"><span class="label1">原创</span><span class="label2">市场动态</span>
          <span class="fr">520</span></div>
          <p class="desc">多种数字化手段在汽车行业销售运营中的应用</p>
          <p class="author"><span></span><span>2018/10/19</span></p>	 
        </dd>                
      </dl>
        <dl>
        <dt>
          <img src="http://picture.eclicks.cn/g2/l/2018/12/29/8b64b3c45968151c_482_315.png" alt="">
        </dt>
        <dd>
          <h2>如何用数字化手段对汽车行业的销售运营进行改造和升级</h2>
          <div class="label"><span class="label1">原创</span><span class="label2">市场动态</span>
          <span class="fr">520</span></div>
          <p class="desc">多种数字化手段在汽车行业销售运营中的应用</p>
          <p class="author"><span></span><span>2018/10/19</span></p>	 
        </dd>                
      </dl>
        <dl>
        <dt>
          <img src="http://picture.eclicks.cn/g2/l/2018/12/29/8b64b3c45968151c_482_315.png" alt="">
        </dt>
        <dd>
          <h2>如何用数字化手段对汽车行业的销售运营进行改造和升级</h2>
          <div class="label"><span class="label1">原创</span><span class="label2">市场动态</span>
          <span class="fr">520</span></div>
          <p class="desc">多种数字化手段在汽车行业销售运营中的应用</p>
          <p class="author"><span></span><span>2018/10/19</span></p>	 
        </dd>                
      </dl>
    </li>
  </ul>
</template>

<script>
export default {

}
</script>

<style>

</style>
