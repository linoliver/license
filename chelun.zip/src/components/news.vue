<template>
  <div>新闻</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
